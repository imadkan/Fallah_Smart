export default function Home() {
  return (
    <div style={{ padding: 20, textAlign: 'center' }}>
      <h1>تطبيق الفلاح الذكي</h1>
      <p>مرحباً بك في النسخة التجريبية من التطبيق التفاعلي لدعم الفلاحين</p>
    </div>
  );
}