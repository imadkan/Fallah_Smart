
import React, { useState } from "react";

function App() {
  const [lang, setLang] = useState("ar");

  const messages = {
    ar: "مرحبا بك في تطبيق الفلاح الذكي! كيف يمكنني مساعدتك؟",
    fr: "Bienvenue dans l'application Fallah Smart ! Comment puis-je vous aider ?"
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial", textAlign: "center" }}>
      <h1>{lang === "ar" ? "الفلاح الذكي" : "Fallah Smart"}</h1>
      <p>{messages[lang]}</p>
      <button onClick={() => setLang("ar")}>🇲🇦 العربية</button>
      <button onClick={() => setLang("fr")}>🇫🇷 Français</button>
    </div>
  );
}

export default App;
